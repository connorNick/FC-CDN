package com.test.TestCompiler;

public class Switch {
    /**
     * Test switch() blocks
     */
    private native static void testSwitch();
    public static void run() {
        testSwitch();
    }
}
