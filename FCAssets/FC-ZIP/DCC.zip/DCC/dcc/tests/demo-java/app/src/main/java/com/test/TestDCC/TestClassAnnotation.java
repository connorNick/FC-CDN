package com.test.TestDCC;

@Dex2C
public class TestClassAnnotation {
    static public void test() {
    }
    static public void test(int i) {
    }
}
