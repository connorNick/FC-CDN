package top.niunaijun.bcore.core.system.user;

public enum BUserStatus {
    ENABLE, DISABLE
}
