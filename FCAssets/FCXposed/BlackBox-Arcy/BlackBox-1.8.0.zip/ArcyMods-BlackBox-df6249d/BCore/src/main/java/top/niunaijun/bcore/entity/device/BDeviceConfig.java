package top.niunaijun.bcore.entity.device;

import android.os.Parcel;
import android.os.Parcelable;

public class BDeviceConfig implements Parcelable {
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) { }
}
