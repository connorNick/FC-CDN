package top.niunaijun.jnihook;

public final class JniHook {
    public static final int NATIVE_OFFSET = 0;

    public static final int NATIVE_OFFSET_2 = 0;

    public static native void nativeOffset();

    public static native void nativeOffset2();
}
