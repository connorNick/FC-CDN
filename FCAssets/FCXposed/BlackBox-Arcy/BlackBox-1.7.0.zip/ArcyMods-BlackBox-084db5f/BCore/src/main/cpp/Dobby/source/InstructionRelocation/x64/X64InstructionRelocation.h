#ifndef INSTRUCTION_RELOCATION_X64_H
#define INSTRUCTION_RELOCATION_X64_H

#include "common_header.h"

#include "core/arch/x64/constants-x64.h"

#include "MemoryAllocator/AssemblyCodeBuilder.h"

#endif