#include "xnucxx/LiteObject.h"

void LiteObject::free() {
  return;
}

void LiteObject::release() {
  return;
}