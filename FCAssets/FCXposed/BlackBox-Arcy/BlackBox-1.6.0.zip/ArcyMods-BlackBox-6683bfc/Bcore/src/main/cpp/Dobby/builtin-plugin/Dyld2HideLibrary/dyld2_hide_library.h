#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int dyld2_hide_library(const char *library_name);

#ifdef __cplusplus
}
#endif