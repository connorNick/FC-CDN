#include <stdio.h>
#include <iostream>

int main(int argc, char const *argv[]) {

  std::cout << "Start..." << std::endl;

  return 0;
}