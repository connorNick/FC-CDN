# QDReadHook
![](https://img.shields.io/badge/Android-7.0%20or%20above-brightgreen.svg)
[![Latest Release](https://img.shields.io/github/release/xihan123/QDReadHook.svg)](../../releases)
![](https://img.shields.io/github/downloads/xihan123/QDReadHook/total)


起点阅读 Xp模块

简单5个功能:
1.自动签到
2.新旧版布局
3.本地至尊卡
4.去书架右下角浮窗
5.去底部导航栏中心广告

# 截图
<img src="https://raw.githubusercontent.com/xihan123/QDReadHook/master/Screenshots/1.jpg" />



