buildscript {
    val appVersionName by extra("1.4.1")
    val appVersionCode by extra(141)
    val minSdkVersion by extra(24)
    val targetSdkVersion by extra(33)
    val coreVersion by extra("1.9.0")
    val appcompatVersion by extra("1.7.0-alpha01")
    val materialVersion by extra("1.8.0-beta01")
    val YuKiHookVersion by extra("1.1.4")


}
plugins {
    id("com.android.application") apply false
    id("com.android.library") apply false
    kotlin("android") apply false
    kotlin("plugin.serialization") apply false
    id("org.jetbrains.dokka")
    id("com.google.devtools.ksp") apply false
}