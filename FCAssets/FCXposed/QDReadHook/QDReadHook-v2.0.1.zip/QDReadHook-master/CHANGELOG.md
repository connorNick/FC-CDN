# Changelog

## [2.0.1](https://github.com/xihan123/QDReadHook/compare/v1.4.1...v2.0.1) (2023-02-02)

### Features

* 适配 `868` 版本
* 具体自己看，懒得说明了

## [1.4.1](https://github.com/xihan123/QDReadHook/compare/v1.4.0...v1.4.1) (2023-01-14)

### Features

* 适配 `858`、`860` 版本

## [1.4.0](https://github.com/xihan123/QDReadHook/compare/v1.3.9...v1.4.0) (2023-01-07)

### Features

* 新增 `854` 版本 "免广告领取奖励自动退出"

* 新增 `854` 版本 "忽略粉丝值跳转加群限制" 

* 新增 `854` 版本 "忽略限时免费批量订阅限制"


## [1.3.9](https://github.com/xihan123/QDReadHook/compare/v1.3.8...v1.3.9) (2023-01-04)

### Features

* 新增 `854` 版本 "免广告领取奖励"

## [1.3.8](https://github.com/xihan123/QDReadHook/compare/v1.3.7...v1.3.8) (2023-01-02)

### Fix

* 修复多个版本 "畅销精选、主编力荐" 屏蔽失效

## [1.3.7](https://github.com/xihan123/QDReadHook/compare/v1.3.6...v1.3.7) (2022-12-29)

### Features

* 适配 `854` 版本

## [1.3.6](https://github.com/xihan123/QDReadHook/compare/v1.3.5...v1.3.6) (2022-12-16)

### Features

* 适配 `850` 版本
