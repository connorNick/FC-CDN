


how to run


python3 run.py nw0.bin ./output


