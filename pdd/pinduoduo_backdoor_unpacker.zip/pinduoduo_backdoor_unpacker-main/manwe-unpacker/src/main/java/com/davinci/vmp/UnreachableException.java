package com.davinci.vmp;

public class UnreachableException extends RuntimeException{
    public UnreachableException(String s){
        super(s);
    }
}
