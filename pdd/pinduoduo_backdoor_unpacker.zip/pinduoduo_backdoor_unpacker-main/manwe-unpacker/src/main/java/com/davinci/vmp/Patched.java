package com.davinci.vmp;

public @interface Patched {
    String value();
}
